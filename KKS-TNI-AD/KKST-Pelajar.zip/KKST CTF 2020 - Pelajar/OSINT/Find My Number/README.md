# Find My Number [999 pts]

**Category:** OSINT
**Solves:** 2

## Description
>Developer pada website https://2020.kks-tniad.id/ sangat suka bermain game bernama Dota 2. Dia memainkannya hampir setiap malam bersama dengan teman-temannya. 

Namun pada suatu hari, ternyata dia mendapatkan tagihan pulsa yang sangat besar dikarenakan adanya seseorang yang tidak bertanggung jawab mengirimkan kode OTP secara massal pada nomor ponselnya.

Bisakah kalian mencari nomor developer tersebut ?

Format Flag: KKST2020{NomorTelepon}

**Hint**
* -

## Solution

### Flag

