# rox [475 pts]

**Category:** Cryptography
**Solves:** 6

## Description
>**WycweDI5JywgJzB4MjknLCAnMHgzMScsICcweDExJywgJzB4NTAnLCAnMHg1YicsICcweDU5JywgJzB4NzUnLCAnMHgzZScsICcweDJhJywgJzB4MjAnLCAnMHgyOCcsICcweDI2JywgJzB4MmUnLCAnMHgyZCcsICcweDFmJ10=**

**Hint**
* -

## Solution

### Flag

