# Kracken [475 pts]

**Category:** Cryptography
**Solves:** 6

## Description
>**5ada0e30fd3c562e3db448f17bbd2169a7ba768c8492798698c3acc8446f1486
**

**Hint**
* -

## Solution

### Flag

