# Suami Suami Takut Istri [491 pts]

**Category:** Web
**Solves:** 3

## Description
>http://207.148.78.100:20005

**Hint**
* -

## Solution

### Flag

