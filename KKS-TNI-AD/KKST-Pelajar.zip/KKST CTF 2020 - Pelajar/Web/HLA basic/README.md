# HLA basic [419 pts]

**Category:** Web
**Solves:** 10

## Description
>HLA http://207.148.78.100:20001

**Hint**
* -

## Solution

### Flag

