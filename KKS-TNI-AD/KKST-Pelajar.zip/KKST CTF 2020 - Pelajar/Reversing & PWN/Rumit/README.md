# Rumit [499 pts]

**Category:** Reversing & PWN
**Solves:** 2

## Description
>Run these commands to build the task.

1. Make sure to use Python 3 and you have installed pyinstaller (using `pip install pyinstaller`).
2. Adjust the flag in `flag.py`.
3. Run `pyinstaller --onefile soal.py`
4. The binary is inside `dist/` directory.

**Hint**
* -

## Solution

### Flag

