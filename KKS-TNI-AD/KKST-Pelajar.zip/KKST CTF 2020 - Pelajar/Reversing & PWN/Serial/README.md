# Serial [475 pts]

**Category:** Reversing & PWN
**Solves:** 6

## Description
>

**Hint**
* -

## Solution

### Flag

