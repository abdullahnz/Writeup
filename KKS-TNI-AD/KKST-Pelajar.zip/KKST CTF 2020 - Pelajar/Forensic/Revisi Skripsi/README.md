# Revisi Skripsi [500 pts]

**Category:** Forensic
**Solves:** 0

## Description
>Revisi gan

**Hint**
* -

## Solution

### Flag

